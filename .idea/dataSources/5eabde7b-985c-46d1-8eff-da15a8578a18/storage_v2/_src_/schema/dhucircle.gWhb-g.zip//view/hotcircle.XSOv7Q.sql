create definer = root@localhost view hotcircle as
select `c`.`circleId`      AS `circleId`,
       `c`.`circleName`    AS `circleName`,
       `c`.`circleImg`     AS `circleImg`,
       `c`.`circleContent` AS `circleContent`,
       `c`.`circleLife`    AS `circleLife`,
       `c`.`circleTime`    AS `circleTime`,
       `c`.`circle_UserId` AS `circle_UserId`,
       sum(`p`.`postGood`) AS `hot`
from (`dhucircle`.`circle` `c` join `dhucircle`.`post` `p`)
where (`p`.`post_CircleId` = `c`.`circleId`)
group by `c`.`circleId`
order by `hot` desc;

-- comment on column hotcircle.circleImg not supported: 圈子头像

-- comment on column hotcircle.circleContent not supported: 圈子简介

-- comment on column hotcircle.circleLife not supported: 圈子是否被封

-- comment on column hotcircle.circleTime not supported: 圈子建立时间（审核通过开始计算）

-- comment on column hotcircle.circle_UserId not supported: 圈主

